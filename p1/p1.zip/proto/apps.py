from django.apps import AppConfig


class ProtoConfig(AppConfig):
    name = 'proto'
