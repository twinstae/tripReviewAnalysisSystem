'use strict';
import Card from './Card';
const e = React.createElement;

class Guide extends React.Component {
  constructor(props) {
    super(props);
    this.state = { progress: 0};
  }

  render() {

    return (
		
    	);
  }
}


